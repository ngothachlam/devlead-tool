package pack1;

import java.awt.Dimension;

import javax.swing.JFrame;

public class MainFunc {
    public static void main(String[] args) {
        JFrame f = new JFrame();
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setSize(new Dimension(300, 300));
        SWTree t = new SWTree();
        //SWTree.fillTree(t.tree);
        f.add(t);
        f.setVisible(true);

        t.InitAddNode(1, 1, "Root");

        t.InitAddNode(2, 2, "Node1");
        //--
        t.InitAddNode(3, 3, "Node1 1");
        t.InitAddNode(4, 3, "Node1 2");
        t.InitAddNode(5, 3, "Node1 3");
        t.InitAddNode(6, 3, "Node1 4");
        t.InitAddNode(7, 3, "Node1 5");

        t.InitAddNode(8, 2, "Node2");
        //--
        t.InitAddNode(9, 3, "Node2 1");
        t.InitAddNode(10, 3, "Node2 2");
        t.InitAddNode(11, 3, "Node2 3");
        t.InitAddNode(12, 3, "Node2 4");
        t.InitAddNode(13, 3, "Node2 5");

    }
}
