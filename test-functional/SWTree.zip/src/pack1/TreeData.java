package pack1;

import java.io.Serializable;

public class TreeData implements Serializable {
    long id;
    String descr;

    public TreeData(long pId, String pDescr) {
        id = pId;
        descr = pDescr;
    }

    public String toString() {
        return descr;
    }
}
