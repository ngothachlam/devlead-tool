package pack1;

import java.util.*;

import java.awt.*;

import javax.swing.*;
import javax.swing.tree.*;

import java.awt.dnd.*;

public class DNDTree extends JTree {

    private String formItemName;
    private Insets autoscrollInsets = new Insets(20, 20, 20, 20); // insets
    private DefaultTreeModel treeModel;
    private static DefaultMutableTreeNode[] arrParentsNodes = 
        new DefaultMutableTreeNode[30]; //more levels?

    public DNDTree() {
        setAutoscrolls(true);
        setRootVisible(true);
        setShowsRootHandles(false); //to show the root icon
        getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION); //set single selection for the Tree
        setEditable(false);
        new DefaultTreeTransferHandler(this, DnDConstants.ACTION_COPY_OR_MOVE);
    }

    public void setFormItemName(String fin) {
        formItemName = fin;
    }
    
    public String getFormItemName() {
        return formItemName;
    }

    public void autoscroll(Point cursorLocation) {
        Insets insets = getAutoscrollInsets();
        Rectangle outer = getVisibleRect();
        Rectangle inner = 
            new Rectangle(outer.x + insets.left, outer.y + insets.top, 
                          outer.width - (insets.left + insets.right), 
                          outer.height - (insets.top + insets.bottom));
        if (!inner.contains(cursorLocation)) {
            Rectangle scrollRect = 
                new Rectangle(cursorLocation.x - insets.left, 
                              cursorLocation.y - insets.top, 
                              insets.left + insets.right, 
                              insets.top + insets.bottom);
            scrollRectToVisible(scrollRect);
        }
    }

    public Insets getAutoscrollInsets() {
        return (autoscrollInsets);
    }

    public static DefaultMutableTreeNode makeDeepCopy(DefaultMutableTreeNode node) {
        DefaultMutableTreeNode copy = 
            new DefaultMutableTreeNode(node.getUserObject());
        for (Enumeration e = node.children(); e.hasMoreElements(); ) {
            copy.add(makeDeepCopy((DefaultMutableTreeNode)e.nextElement()));
        }
        return (copy);
    }

    public DefaultMutableTreeNode AddSpecNode(DefaultMutableTreeNode parent, 
                                              Object child) {
        DefaultMutableTreeNode childNode = new DefaultMutableTreeNode(child);
        if (treeModel == null) {
            treeModel = new DefaultTreeModel(childNode);
            setModel(treeModel);
        } else {
            treeModel.insertNodeInto((MutableTreeNode)childNode, 
                                     (MutableTreeNode)parent, 
                                     parent.getChildCount());
        }
        scrollPathToVisible(new TreePath(childNode.getPath()));

        return childNode;
    }

    public void InitAddNode(int id, int level, String descr) {
        DefaultMutableTreeNode nd;
        nd = AddSpecNode((level > 1) ? arrParentsNodes[level - 1] : null, new TreeData(id, descr));
        arrParentsNodes[level] = nd;
    }

    public void RunAddNode(int id, String descr) {
        DefaultMutableTreeNode nd;
        nd = AddSpecNode((DefaultMutableTreeNode)this.getLastSelectedPathComponent(), new TreeData(id, descr));
    }

    public void RunRemoveNode() {
        treeModel.removeNodeFromParent((DefaultMutableTreeNode)this.getLastSelectedPathComponent());
    }
}
