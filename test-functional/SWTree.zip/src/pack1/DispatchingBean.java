package pack1;

/* DispatchingBean is a bean that will dispatch an event to forms
 * It will be called by the DispatchingPJC as an example
 *
 * This method can be used to workaround that dispatching cannot
 * be done using PJCs
 * */

import java.awt.Component;
import java.awt.Container;
import java.awt.Frame;

import oracle.forms.engine.Main;
import oracle.forms.handler.IHandler;
import oracle.forms.ui.CustomEvent;
import oracle.forms.ui.VBean;
import oracle.forms.properties.ID;
import oracle.forms.ui.VTextField;

public class DispatchingBean extends VBean {
    private IHandler mHandler;
    private Frame formsTopFrame = null;
    private Main formsMain = null;
    private static final ID MYEVENT = ID.registerProperty("MYEVENT");
    private static final ID MYVALUE = ID.registerProperty("MYVALUE");
    private static final ID FINDCOMPS = ID.registerProperty("FINDCOMPS");

    public DispatchingBean() {
    }

    public void init(IHandler handler) {
        mHandler = handler;
        super.init(handler);
        formsMain = (Main)mHandler.getApplet();
        formsTopFrame = formsMain.getFrame();
    }

    public boolean setProperty(ID id, Object value) {
        if (id == FINDCOMPS) { /* walkFindPJC will locate the DispatchingFBean & DispatchingPJC
      * and will set the dBean to this component
      * */

            walkFindPJC(formsTopFrame, 0);
            return true;
        }

        return super.setProperty(id, value);
    }

    public void dispatchanevent(String value) { // this is the method that will dispatch the customEvent to forms
        try {
            mHandler.setProperty(MYVALUE, value);
            CustomEvent ce = new CustomEvent(mHandler, MYEVENT);
            dispatchCustomEvent(ce);
        } catch (Exception e) {
            System.out.println("exception while dispatching: " + e);
        }
    }

    protected void walkFindPJC(Component component, int iter) {
        if (component.getClass().getName().equals("pack1.SWTree")) {
            SWTree DFBean = (SWTree)component;
            DFBean.dBean = this;
        }
        if (component instanceof Container) {
            Component components[] = ((Container)component).getComponents();
            iter++;
            for (int i = 0; i < components.length; i++) {
                if (components[i] != null) {
                    walkFindPJC(components[i], iter);
                }
            }
        }
    }

}
