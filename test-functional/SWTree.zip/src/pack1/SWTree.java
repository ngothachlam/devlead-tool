package pack1;

import java.awt.BorderLayout;

import java.awt.Component;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JScrollPane;

import javax.swing.tree.DefaultMutableTreeNode;

import oracle.forms.ui.VBean;

public class SWTree extends VBean {

    private DNDTree tree;
    public static DispatchingBean dBean;

    public SWTree() {
        try {
            createTree();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setFormItemName(String fin) {
        tree.setFormItemName(fin);
    }

    public void createTree() {
        try {
            JScrollPane scrollPane = new JScrollPane();
            tree = new DNDTree();
            //--
            MouseListener ml = new MouseAdapter() {
                    public void mousePressed(MouseEvent e) {
                        jTree_mousePressed(e);
                    }
                };
            tree.addMouseListener(ml);
            tree.addKeyListener(new java.awt.event.KeyAdapter() {
                        public void keyTyped(KeyEvent e) {
                            jTree_keyTyped(e);
                        }
                    });
            //--
            scrollPane.getViewport().add(tree, null);
            this.add(scrollPane, BorderLayout.CENTER);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    private void jTree_keyTyped(KeyEvent e) {
        int id = e.getID();
        if (id == KeyEvent.KEY_TYPED) {
            if (e.getKeyChar() == KeyEvent.VK_ENTER) {
                dBean.dispatchanevent(
                      tree.getFormItemName()
                    + "^KEY-ENTER^"
                    + GetNodeData((DefaultMutableTreeNode)tree.getLastSelectedPathComponent()));
                //System.out.println("KEY-ENTER");
            }
        }
        super.processKeyEvent(e);
    }

    public void jTree_mousePressed(MouseEvent e) {
        int selRow = tree.getRowForLocation(e.getX(), e.getY());
        if (selRow != -1) {
            if (e.getClickCount() == 2) { //Double click
                dBean.dispatchanevent(
                      tree.getFormItemName()
                    + "^MOUSE-DOUBLECLICK^"
                    + GetNodeData((DefaultMutableTreeNode)tree.getLastSelectedPathComponent()));
                //System.out.println("MOUSE-DOUBLECLICK");
            } else {
                dBean.dispatchanevent(
                      tree.getFormItemName()
                    + "^MOUSE-CLICK^"
                    + GetNodeData((DefaultMutableTreeNode)tree.getLastSelectedPathComponent()));
                //System.out.println("MOUSE-CLICK^" + GetNodeData((DefaultMutableTreeNode)tree.getLastSelectedPathComponent()));
            }
        }
        super.processMouseEvent(e);
    }

    public static String GetNodeData(DefaultMutableTreeNode node) {
        String retVal = null;
        if (node != null) {
            TreeData nodeInfo = (TreeData)node.getUserObject();
            if (nodeInfo != null) {
                retVal = nodeInfo.id + "^" + nodeInfo.descr;
            }
        }
        return retVal;
    }

    public void InitAddNode(int id, int level, String descr) {
        tree.InitAddNode(id, level, descr);
    }

    public void RunAddNode(int id, String descr) {
        tree.RunAddNode(id, descr);
    }

    public void RunRemoveNode() {
        tree.RunRemoveNode();
    }
}
