drop table Sample_Tree;
create table Sample_Tree (
  id number primary key,
  descr varchar2(50),
  parent_id number
);

alter table Sample_Tree
  add constraint fk_Sample_Tree_parent_id
  foreign key (parent_id)
  references Sample_Tree (id);

drop sequence Seq_Sample_Tree;
create sequence Seq_Sample_Tree;

create or replace view test_swing_tree_01 as
  select id, level levelDepth, descr
    from Sample_Tree
   start with parent_id is null
 connect by prior id = parent_id
   order siblings by descr;

insert into Sample_Tree values (Seq_Sample_Tree.nextval,  'Node1',  null);
insert into Sample_Tree values (Seq_Sample_Tree.nextval,  'Node2',  1);
insert into Sample_Tree values (Seq_Sample_Tree.nextval,  'Node3',  2);
insert into Sample_Tree values (Seq_Sample_Tree.nextval,  'Node4',  2);
insert into Sample_Tree values (Seq_Sample_Tree.nextval,  'Node5',  2);
insert into Sample_Tree values (Seq_Sample_Tree.nextval,  'Node6',  1);
insert into Sample_Tree values (Seq_Sample_Tree.nextval,  'Node7',  6);
insert into Sample_Tree values (Seq_Sample_Tree.nextval,  'Node8',  6);
insert into Sample_Tree values (Seq_Sample_Tree.nextval,  'Node9',  6);
commit;

 select lpad(' ', 5*(level-1)) || descr tr
   from Sample_Tree
  start with parent_id is null
connect by prior id = parent_id
  order siblings by descr;
